package com.nova.client;

import com.nova.client.gui.Theme;
import com.nova.client.module.BindSetting;
import com.nova.client.module.Module;
import com.nova.client.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Saves the assigned keys and the theme color to config/novaclient.properties. */
public final class ConfigManager {
    private ConfigManager() { }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("novaclient.properties");
    }

    public static void load() {
        Path file = file();
        if (!Files.exists(file)) return;
        Properties props = new Properties();
        try (InputStream in = Files.newInputStream(file)) {
            props.load(in);
        } catch (IOException e) {
            return;
        }

        String theme = props.getProperty("theme");
        if (theme != null) {
            try { Theme.set(Integer.parseInt(theme)); } catch (NumberFormatException ignored) { }
        }
        for (Module module : ModuleManager.getModules()) {
            for (Object s : module.getSettings()) {
                if (!(s instanceof BindSetting bind)) continue;
                String value = props.getProperty(propertyName(module, bind));
                if (value == null) continue;
                try { bind.setKey(Integer.parseInt(value)); } catch (NumberFormatException ignored) { }
            }
        }
    }

    public static void save() {
        Properties props = new Properties();
        props.setProperty("theme", Integer.toString(Theme.rgb()));
        for (Module module : ModuleManager.getModules()) {
            for (Object s : module.getSettings()) {
                if (s instanceof BindSetting bind) {
                    props.setProperty(propertyName(module, bind), Integer.toString(bind.getKey()));
                }
            }
        }
        try (OutputStream out = Files.newOutputStream(file())) {
            props.store(out, "NovaClient");
        } catch (IOException ignored) { }
    }

    private static String propertyName(Module module, BindSetting bind) {
        return "bind." + module.getName() + "." + bind.getName();
    }
}
