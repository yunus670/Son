package com.nova.client;

import com.nova.client.gui.ClickGuiScreen;
import com.nova.client.input.KeyEvents;
import com.nova.client.module.Module;
import com.nova.client.module.ModuleManager;
import com.nova.client.module.impl.ClickGuiModule;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class NovaClient implements ClientModInitializer {
    /**
     * A real Minecraft key binding (shows up in Controls, can be rebound). Launchers like
     * ZalithLauncher / PojavLauncher can map an on-screen button to it, and it never misses a
     * quick tap the way polling the keyboard once per tick does.
     */
    public static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ConfigManager.load();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.novaclient.clickgui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, "category.novaclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                ClickGuiModule gui = ModuleManager.get(ClickGuiModule.class);
                if (gui != null && client.player != null && client.currentScreen == null) gui.toggle();
            }
            ModuleManager.handleKeybinds(client);
            if (client.player != null && client.world != null) {
                for (Module module : ModuleManager.getModules()) {
                    if (module.isToggled()) module.onTick();
                }
            }
            KeyEvents.clear();
        });

        // Touch friendly way in: a NovaClient button on the pause menu (no keyboard needed).
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("NovaClient"),
                        button -> client.setScreen(new ClickGuiScreen())).dimensions(6, 6, 90, 20).build());
            }
        });

        WorldRenderEvents.LAST.register(context -> {
            if (context.matrixStack() == null) return;
            float tickProgress = context.tickCounter().getTickDelta(false);
            for (Module module : ModuleManager.getModules()) {
                if (module.isToggled()) {
                    module.onRender3D(context.matrixStack(), context.camera().getPos(), tickProgress);
                }
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            for (Module module : ModuleManager.getModules()) {
                if (module.isToggled()) module.onRender2D(drawContext);
            }
        });
    }
}
