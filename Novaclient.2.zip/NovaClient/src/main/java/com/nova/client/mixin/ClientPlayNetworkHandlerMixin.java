package com.nova.client.mixin;

import com.nova.client.module.ModuleManager;
import com.nova.client.module.impl.VelocityModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** After the game applied the knockback packet to the player, scale the player's velocity. */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("TAIL"))
    private void nova$velocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player == null || packet.getEntityId() != player.getId()) return;

        VelocityModule module = ModuleManager.get(VelocityModule.class);
        if (module == null || !module.isToggled()) return;

        Vec3d scaled = module.process(player.getVelocity());
        player.setVelocity(scaled);

        // Jump Reset happens after the scaling, so the jump keeps the reduced horizontal speed.
        if (module.shouldJumpReset(player)) {
            ((LivingEntityInvoker) player).nova$invokeJump();
        }
    }
}
