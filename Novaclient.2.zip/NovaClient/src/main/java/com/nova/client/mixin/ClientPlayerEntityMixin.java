package com.nova.client.mixin;

import com.nova.client.rotation.RotationManager;
import com.nova.client.module.ModuleManager;
import com.nova.client.module.impl.AuraModule;
import net.minecraft.client.MinecraftClient;
import net.attackaura.aura.AttackAura;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * While a silent rotation is active, the movement packet is built with the silent
 * rotation, then the player's real (camera) rotation is put back right after.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Unique private float nova$camYaw;
    @Unique private float nova$camPitch;
    @Unique private boolean nova$swapped;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void nova$beforeSend(CallbackInfo ci) {
        AuraModule aura = ModuleManager.get(AuraModule.class);
        if (aura != null && aura.isToggled()) {
            AttackAura.onClientTick(MinecraftClient.getInstance());
        } else {
            AttackAura.clearTarget();
        }
        if (!RotationManager.isActive()) return;
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        nova$camYaw = self.getYaw();
        nova$camPitch = self.getPitch();
        self.setYaw(RotationManager.getYaw());
        self.setPitch(RotationManager.getPitch());
        nova$swapped = true;
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void nova$afterSend(CallbackInfo ci) {
        if (!nova$swapped) return;
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        self.setYaw(nova$camYaw);
        self.setPitch(nova$camPitch);
        nova$swapped = false;
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void nova$attackAfterMovement(CallbackInfo ci) {
        AuraModule aura = ModuleManager.get(AuraModule.class);
        if (aura != null && aura.isToggled()) {
            AttackAura.onPostMovementPackets(MinecraftClient.getInstance());
        }
    }
}
